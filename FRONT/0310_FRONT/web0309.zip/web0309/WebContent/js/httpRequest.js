function sendRequest(url, params, callback, method){
	var httpRequest=new XMLHttpRequest();
	
	var httpMethod="GET";
	
	var httpParams=params==null||params==""?null:params;
	var httpUrl=url;
	
	if(httpMethod=="GET" && httpParams!=null){
		httpUrl=httpUrl+"?"+httpParams;
	}
	
	httpRequest.open(httpMethod, httpUrl, true);
	httpRequest.onreadystatechange=callback;
	return httpRequest;
}