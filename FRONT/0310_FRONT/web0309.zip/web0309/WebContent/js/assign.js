function signUp(){
	var idd=$("#id");
	var pw=$("#pw");
	var name=$("#name");
	var phone=$("#phone");
	var email=$("#email");
	var address=$("#address");
	if(idd.val().trim()==""){
		alert("아이디를 입력해 주세요")
		return;
	}
	if(pw.val().trim()==""){
		alert("비밀번호를 입력해 주세요")
		return;
	}
	if(name.val().trim()==""){
		alert("이름을 입력해 주세요")
		return;
	}
	if(phone.val().trim()==""){
		alert("핸드폰 번호를 입력해 주세요")
		return;
	}
	if(email.val().trim()==""){
		alert("이메일을 입력해 주세요")
		return;
	}
	if(address.val().trim()==""){
		alert("주소를 입력해 주세요")
		return;
	}

	$.ajax({
        url: './data/userlist.xml',
        type: 'GET',
        dataType: 'xml',
		success:function(data){
			var check=true;
			$(data).find('user').each(function(index){
				var reid=$(this).find('id').text();
				if(reid==idd.val()){
					check=false;		
				}
			})
			if(check==false){
				alert("다른 아이디를 입력해 주세요.");
				return;
			}
			alert("회원가입 되었습니다.");
		},
		error:function(request,status,error){
			alert("code:"+request.status+"\n"+"erro:"+error);
		}

	})
}
