
function openModal(){
	document.get
	$("#myModal").fadeIn(300);
}
function closeModal(){
	document.get
	$("#myModal").fadeOut(300);
}
function logi(){
	var id=$("#id").val();
	var pw=$("#pw").val();
	$.ajax({
        url: './data/userlist.xml',
        type: 'GET',
        dataType: 'xml',
		success:function(dat){
			var check=false;
			$(dat).find('user').each(function(index){
				var reid=$(this).find('id').text();
				var repw=$(this).find('password').text();
				if(reid==id && repw==pw){
					check=true;
				}
			})
			if(check==true){
				alert("로그인 되었습니다.");
				$("#login").hide();
				$("#assign").hide();
				$("#logOut").show();
				$("#showId").show();
				$("#showId").html("아이디 :"+id);
				closeModal();
			}
			else{
				alert("해당 아이디와 비밀번호가 없습니다.");
			}
			
			
		},
		error:function(request,status,error){
			alert("code:"+request.status+"\n"+"erro:"+error);
		}

	})
}

