$(document).ready(function () {
  var question = localStorage.getItem('question');
  var poll;

  if (question) {
    var answers = localStorage.getItem('answers');
    var answersArr = JSON.parse(answers);
    var len = answersArr.length;
    poll = `
    <div class="vote-title">[ 당신의 선택 ]</div>
    <div class="vote-question">${question}</div>
    <div class="vote-answer">
      <ul>
  `;
    for (var i = 0; i < len; i++) {
      poll += `
        <li>
          <label><input type="radio" name="vote-answer" value="${answersArr[i]}" /> ${answersArr[i]}</label>
        </li>
    `;
    }
    poll += `
      </ul>
    </div>
    <div class="vote-button">
      <button id="btn-poll" class="button btn-primary">투표하기</button>
      <button class="button">결과보기</button>
    </div>
    <div class="vote-date">투표기간 : 21.03.01 ~ 20.03.31</div>
  `;

    $('.content-left-poll').html(poll);
    $('.content-left-poll-btn').css('display', 'none');
    $('.content-left-poll').css('display', '');
  } else {
    poll = `진행중인 투표가 없습니다.`;
    $('.content-left-poll').html(poll);

    $('.content-left-poll-btn').css('display', '');
    $('.content-left-poll').css('display', '');
  }

  $('#btn-makepoll').click(function () {
    window.open('makepoll.html', 'poll', 'width=420,height=300,top=300,left=400');
  });

  $(document).on('click', '#btn-poll', function () {
    var sel_menu = $("input[name='vote-answer']:checked").val();
    alert(sel_menu + '를 선택했습니다.');
  });
});
