import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTest3 {

	public static void main(String[] args){
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			// 1. Driver Loading
			Class.forName("com.mysql.cj.jdbc.Driver");
			// 2. Connection 
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
			// 3. PreparedStatement Create
			ps = con.prepareStatement(
							" update regions set region_name = ? where region_id = ? ");
			ps.setString(1, "MOON");
			ps.setInt(2, 6);
			int ret = ps.executeUpdate();
			
			if( ret == 1 ) {
				System.out.println("수정하였습니다.");
			}
			
			ps.close();
			
			ps = con.prepareStatement(" select region_id, region_name from regions where region_id in ( 5, 6 )  ");
			rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println( rs.getInt(1) + " " + rs.getString(2));
			}
		}catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close(); ps.close(); con.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
