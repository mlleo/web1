import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JDBCTest2 {

	public static void main(String[] args) throws Exception{
		// 1. Driver Loading
		Class.forName("com.mysql.cj.jdbc.Driver");
		// 2. Connection 
		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
		// 3. PreparedStatement Create
		PreparedStatement ps = 
				con.prepareStatement(
						" insert into regions (region_id, region_name) values (?, ?)");
		ps.setInt(1, 5);
		ps.setString(2, "KOREA");
//		ps.setInt(1, 6);
//		ps.setString(2, "SPACE");
		int ret = ps.executeUpdate();
		if( ret == 1 ) {
			System.out.println("등록하였습니다.");
		}
		ps.close();
		con.close();
	}

}
