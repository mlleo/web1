import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTest4 {

	public static void main(String[] args){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch( ClassNotFoundException e ) {
			e.printStackTrace();
		}
		
		//
		try( 
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
			PreparedStatement psDelete = con.prepareStatement( "delete from regions where region_id in ( ?, ? ) ");
			PreparedStatement psSelect = con.prepareStatement( "select region_id, region_name from regions ");
		){
			psDelete.setInt(1, 5);
			psDelete.setInt(2, 6);
			psDelete.executeUpdate();
			
			ResultSet rs = psSelect.executeQuery();
			while(rs.next()){
				System.out.println( rs.getInt("region_id") + " : " + rs.getString("region_name") );
			}
		}catch( SQLException e ) {
			e.printStackTrace();
		}
	}

}
