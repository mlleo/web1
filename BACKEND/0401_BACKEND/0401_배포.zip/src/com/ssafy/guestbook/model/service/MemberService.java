package com.ssafy.guestbook.model.service;

public interface MemberService {

//	회원가입
	
//	로그인
	
//	회원정보 수정을 위한 회원의 모든 정보 얻기
	
//	회원정보 수정
	
//	회원탈퇴
	
	
}
