package com.ssafy.guestbook.model.service;

public interface GuestBookService {

//	글작성
	
//	글목록
	
//	글수정을 위한 글얻기
	
//	글수정
	
//	글삭제
	
}
