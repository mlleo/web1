package com.ssafy.util;

public class DBUtil {

	private final String URL = "jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private final String ID = "ssafy";
	private final String PASSWORD = "ssafy";
	
}
