package com.ssafy.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.member.dto.GuestBookDto;
//Data Access Object
public class GuestBookDao {
	
	
	public GuestBookDao() {
		init();
	}

	private void init()  {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("1/6 S");
		} catch (ClassNotFoundException e) {
			System.out.println("1/6 F");
		}
	}
	
	public Connection getConnection() throws SQLException {
		Connection conn=null;
		conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8", "ssafy5", "ssafy");
		return conn;
	}
	
	public void close(Connection conn, PreparedStatement psmt, ResultSet rs) {
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				
			}
		}
		if(psmt!=null) {
			try {
				psmt.close();
			} catch (SQLException e) {
				
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				
			}
		}
	}
	
	/*
	public boolean addMember(MemberDto mdto) {
		Connection conn=null;
		PreparedStatement psmt=null;
		int count=0;
		String sql=" INSERT INTO ssafy_member(userid, username, userpwd, email, address,joindate) \r\n" + 
				" VALUES(?, ?, ?, ?,?,now() )   \r\n" ;
		try {
			conn=getConnection();
			//System.out.println("2/6 S");
			//System.out.println(sql);
			psmt=conn.prepareStatement(sql);
			int i=1;
			psmt.setString(i++,mdto.getUserId());
			psmt.setString(i++,mdto.getUserName());
			psmt.setString(i++,mdto.getUserPwd() );
			psmt.setString(i++,mdto.getEmail() );
			psmt.setString(i++,mdto.getAddress() );
			//System.out.println("3/6 S");
			count=psmt.executeUpdate();
			//System.out.println("4/6 S");
		} catch (SQLException e) {
			System.out.println("addMember F "+ e);
		}finally {
			close(conn, psmt, null);
			//System.out.println("6/6 S");
		}
		
		return count>0?true:false;
	} */
	
	
	public List<GuestBookDto> getGuestBooks( ) {
		List<GuestBookDto> guests=new ArrayList<>();
		Connection conn=null;
		PreparedStatement psmt=null;
		ResultSet rs=null;
		String sql=" select articleno, userid, subject, content , regtime "
				+  " from guestbook  order by   articleno                " ;
		try {
			conn=getConnection();
			System.out.println("2/6 S");
			System.out.println(sql);
			psmt=conn.prepareStatement(sql);
			System.out.println("3/6 S");
			rs=psmt.executeQuery();
			System.out.println("4/6 S");
			while(rs.next()) {
				int i=1;
				GuestBookDto guest=new GuestBookDto(
						rs.getInt(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getString(i++));
				guests.add(guest);
			}
			System.out.println("5/6 S");
		} catch (SQLException e) {
			System.out.println("getGuestBooks F "+ e);
		}finally {
			close(conn, psmt, null);
			System.out.println("6/6 S");
		}
		
		return guests;
	} 
	
	
	
}
