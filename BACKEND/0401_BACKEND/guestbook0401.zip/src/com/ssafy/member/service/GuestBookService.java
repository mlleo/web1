package com.ssafy.member.service;
import java.util.List;
import com.ssafy.member.dto.GuestBookDto;
public interface GuestBookService {
	List<GuestBookDto> getGuestBooks( );
}
