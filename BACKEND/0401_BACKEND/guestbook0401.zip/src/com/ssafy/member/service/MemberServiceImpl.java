package com.ssafy.member.service;

import com.ssafy.member.dao.MemberDao;
import com.ssafy.member.dto.MemberDto;
//MemberService
public class MemberServiceImpl implements MemberService{

	private static MemberServiceImpl manager=new MemberServiceImpl();
	
	private MemberDao dao;
	
	private MemberServiceImpl() {
		dao=new MemberDao();
	}
	
	public static MemberServiceImpl getInstance() {
		return manager;
	}
	
	
	@Override
	public boolean addMember(MemberDto mdto) {
		return dao.addMember(mdto);
	}
	@Override
	public MemberDto login(MemberDto mdto) {
		return dao.login(mdto);
	}
	
}
