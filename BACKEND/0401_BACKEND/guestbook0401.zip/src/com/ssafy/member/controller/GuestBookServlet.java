package com.ssafy.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.member.service.GuestBookService;
import com.ssafy.member.service.GuestBookServiceImpl;

@WebServlet("/main")
//@WebServlet(urlPatterns= {"/a","/b"})
public class GuestBookServlet extends HttpServlet {
 
	private static final long serialVersionUID = 8514852546195110566L;


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		//PrintWriter out=response.getWriter();//
		GuestBookService gbmanager=GuestBookServiceImpl.getInstance();
		
		String root = request.getContextPath();
		
		String act = request.getParameter("act");
		if(act.equalsIgnoreCase("guestlist")) {
			request.setAttribute("guests", gbmanager.getGuestBooks());
			go(true,"./guest/guestbooks.jsp",request, response);
		} 
	}
	
	public void go(boolean isS,String path,HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if(isS) {
			RequestDispatcher dispatcher=request.getRequestDispatcher(path);
			dispatcher.forward(request, response);
		}else {
			response.sendRedirect(path);
		}
	}
	
}
